function iflog(){
if (login===true){
    console.log("login successful")
    if(window.location.href==='./Ourclasses.html'){
          window.location.href('./Classes.html')
    }
    else{
        window.location.href('./MySchedule.html')
    }
}
else{
    console.log("login failed")

}
}
function addsch() {
  const classlist=document.querySelectorAll(".class");
  const couchlist=document.querySelectorAll(".couch");
  const roomlist=document.querySelectorAll(".room");
  const datelist=document.querySelectorAll(".date");
  classlist.forEach(c => {
     classch=[classlist.innerHTML.value,couchlist.innerHTML.value,roomlist.innerHTML.value,datelist.innerHTML.value]

    });
    const row = document.createElement("tr");
    classlist.forEach(index => {
    row.appendChild(document.createElement("td")=classch[index]);
    }
    );
    document.getElementById("mysch").appendChild(row);
}
addsch()