from flask import Flask, render_template, request,redirect,url_for,flash, send_from_directory,send_file,abort
from flask_sqlalchemy import SQLAlchemy
import os
import io
from datetime import datetime
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from sqlalchemy import MetaData



app = Flask(__name__,template_folder='templates')
basedir = os.path.abspath(os.path.dirname(__file__))



app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir,'websitedata1.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
app.config['SECRET_KEY'] = 'your_secret_key'
db=SQLAlchemy(app)

login_manager = LoginManager(app)


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    datebirth = db.Column(db.DateTime, nullable=False)
    role = db.Column(db.String(20), nullable=False)

    __mapper_args__ = {
        'polymorphic_identity': 'user',
        'polymorphic_on': role
    }

class Admin(User):
    id = db.Column(db.Integer, db.ForeignKey('user.id'), primary_key=True, autoincrement=True)
    adminname = db.Column(db.String(20), unique=True, nullable=False)

    __mapper_args__ = {
        'polymorphic_identity': 'admin',
    }

class Guest(User):
    id = db.Column(db.Integer, db.ForeignKey('user.id'), primary_key=True, autoincrement=True)
    guestname = db.Column(db.String(20), unique=True, nullable=False)
    enrollments = db.relationship('SessionEnrolled', back_populates='guest')

    __mapper_args__ = {
        'polymorphic_identity': 'guest',
    }

class Coach(User):
    id = db.Column(db.Integer, db.ForeignKey('user.id'), primary_key=True, autoincrement=True)
    expertise = db.Column(db.String(100), nullable=False)
    coachname = db.Column(db.String(20), unique=True, nullable=False)
    sessions = db.relationship('Session', back_populates='coach')
    img = db.Column(db.LargeBinary, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    mimetype = db.Column(db.String(50), nullable=False)
    __mapper_args__ = {
        'polymorphic_identity': 'coach',
    }
    def __init__(self, username, email, password, datebirth, expertise, coachname, img, name, mimetype):
        super().__init__(username=username, email=email, password=password, datebirth=datebirth,role='coach')
        self.expertise = expertise
        self.coachname = coachname
        self.img = img
        self.name = name
        self.mimetype = mimetype

    
    


class Session(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    class_name= db.Column(db.String(100), nullable=False)
    coach_id = db.Column(db.Integer, db.ForeignKey('coach.id'), nullable=False)
    coach = db.relationship('Coach', back_populates='sessions')
    class_time = db.Column(db.DateTime, nullable=False)
    room = db.Column(db.String(20), nullable=False)
    enrollments = db.relationship('SessionEnrolled', back_populates='session')
class SessionEnrolled(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(100))
    address = db.Column(db.String(100), nullable=False)
    country = db.Column(db.String(255), nullable=False)
    payment_method = db.Column(db.String(10)) 
    session_id = db.Column(db.Integer, db.ForeignKey('session.id'), nullable=False)
    guest_id = db.Column(db.Integer, db.ForeignKey('guest.id'), nullable=False)

    session = db.relationship('Session', back_populates='enrollments')
    guest = db.relationship('Guest', back_populates='enrollments')


with app.app_context():
    db.create_all()
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))
@login_manager.unauthorized_handler
def unauthorized():
    # Redirect the user to the login page
    return redirect(url_for('login'))

#index
@app.route('/')
def index():
    return render_template('index.html',auth=current_user.is_authenticated)
#show what the guest have session to attend
@app.route('/Session')
@login_required
def session():
    enrollments = SessionEnrolled.query.filter_by(guest_id=current_user.id).all()
    return render_template('MySchedule.html', enrollments=enrollments)
#login
@app.route('/Login',methods=['GET', 'POST'])
def login(): 
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    if request.method == 'POST':
        try_email=request.form['email']
        try_password=request.form['password']
        user=User.query.filter_by(email=try_email).first()

        
        if user and  check_password_hash(user.password, try_password): 
            
            login_user(user)
            
            return redirect(url_for('index'))
        return render_template('Login.html')
    return render_template('Login.html')
#sign up
@app.route('/SignUp', methods=['GET', 'POST'])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    if request.method == 'POST':
        date_in=request.form['birthday']
        date_out= datetime.strptime(date_in, '%Y-%m-%dT%H:%M')
        newguest =Guest( username=request.form['username'],email=request.form['email']
                         , password=generate_password_hash(request.form['password']),datebirth=date_out
                         ,guestname=request.form['username'],role='guest')
        
        db.session.add(newguest)
        db.session.commit()
        login_user(newguest)
        return redirect(url_for('index'))
    return render_template('SignUp.html')
#logout
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

#enroll in session    
@app.route('/Classes', methods=['POST','GET'])
@login_required
def classes():
    if request.method=='POST':
        first_name = request.form['firstName']
        last_name = request.form['lastName']
        email = request.form['email']
        address = request.form['address']
        country = request.form['country']
        payment_method = request.form['paymentMethod']
        session_id = request.form['session']  # Assume you have a way to get this from the form
        guest_id = current_user.id # Assume you have a way to get this from the form

        new_address = SessionEnrolled(first_name=first_name,last_name=last_name,email=email,address=address,country=country,payment_method=payment_method,session_id=session_id,guest_id=guest_id)
        db.session.add(new_address)
        db.session.commit()
        return redirect(url_for("session"))
    if (Session.query.count)==0:
        return redirect(url_for('OurClasses'))
    session = Session.query.all()
    
    return render_template('Classes.html',session=session)
#history
@app.route('/history')
def history():
    return render_template('history.html')
#the class that you can enroll in
@app.route('/OurClasses')
def ourclasses():
    isadmin=False
    if current_user.role == 'admin':
        isadmin=True
    if (Session.query.count)==0:
        return redirect(url_for('OurClasses'))
    session = Session.query.all()
    
    return render_template('OurClasses.html',session=session,isadmin=isadmin)
#the upcomingevents
@app.route('/UpcomingEvents')
def UpcomingEvents():
    return render_template('UpcomingEvents.html')
#ourteam
@app.route('/OurTeam', methods=['POST','GET'])
@login_required
def coach():
    if current_user.role == 'admin':
        isadmin=True
    if (Coach.query.count)==0:
        return redirect(url_for('OurTeam'))
    coach = Coach.query.all()
    

    return render_template('OurTeam.html', coach=coach,isadmin=isadmin)
#add a session to the database
@app.route('/api/add_session', methods=['GET', 'POST'])
@login_required
def add_session():
    if request.method == 'POST':
        class_name= request.form['className']
        coach_id = request.form['coach_id']
        date_in=request.form['time']
        class_time= datetime.strptime(date_in, '%Y-%m-%dT%H:%M')
        room = request.form['class_room']
   
        # Check if the form data is valid
        if coach_id and class_time and room:
            new_session = Session(class_name=class_name,coach_id=coach_id, class_time=class_time, room=room)
            db.session.add(new_session)
            db.session.commit()
    return render_template('add_session.html')
# add coach to database
@app.route('/api/add_coach', methods=['GET', 'POST'])
@login_required
def add_coach():
    if request.method == 'POST':
        date_in=request.form['birthday']
        date_out= datetime.strptime(date_in, '%Y-%m-%dT%H:%M')
        if 'pic' not in request.files:
          return 'No file part', 400

        pic = request.files['pic']

        if pic.filename == '':
          return 'No selected file', 400

        filename = secure_filename(pic.filename)
        mimetype = pic.mimetype

        if not filename or not mimetype:
          return 'Bad upload!', 400
        new_coach = Coach(username=request.form['username'], email=request.form['email']
                          , password=generate_password_hash(request.form['password'])
                          , datebirth=date_out, expertise=request.form['expertise'],coachname=request.form['username']
                          ,img=pic.read(), name=filename, mimetype=mimetype)
        db.session.add(new_coach)
        db.session.commit()
    return render_template('add_coach.html')

@app.route('/image/<int:coach_id>')
def get_image(coach_id):
    coach = Coach.query.get_or_404(coach_id)
   
    return send_file(io.BytesIO(coach.img), mimetype=coach.mimetype)

#delete coach
@app.route('/api/deleteCoach/<int:coach_id>', methods=['POST'])
@login_required
def delete_coach(coach_id):
    coach = Coach.query.get_or_404(coach_id)
    db.session.delete(coach)
    db.session.commit()
    return redirect(url_for('coach'))

#delete session
@app.route('/api/Delete/<int:id>', methods=['DELETE'])
@login_required
def delete_session(id):
    session = Session.query.get_or_404(id)
    db.session.delete(session)
    db.session.commit()
    return redirect(url_for('session'))

if __name__== '__main__':

     app.run(debug=True)
